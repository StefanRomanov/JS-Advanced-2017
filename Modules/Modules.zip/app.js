result.Entity = require('./entity');
result.Dog = require('./dog');
result.Person = require('./fourth-task-person');
result.Student = require('./student');